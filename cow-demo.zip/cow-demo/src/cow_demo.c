/*
 * cow_demo.c - Copy-on-Write Memory Demonstrator (Linux)
 *
 * Shows, with real kernel data, that after fork():
 *   1. parent and child initially SHARE the same physical pages,
 *   2. READING does not copy anything (no page faults),
 *   3. the first WRITE to a page triggers a minor page fault and the kernel
 *      gives the writer its OWN private copy of just that page,
 *   4. the other process never sees the change (isolation).
 *
 * Evidence sources (all unprivileged except PFN display):
 *   - /proc/self/pagemap  bit 63 = present, bit 56 = "exclusively mapped"
 *                         (page is mapped by exactly one process), bits 0-54 = PFN
 *   - getrusage(RUSAGE_SELF).ru_minflt = number of minor page faults
 *   - content verification of every page in both processes
 *
 * Build : make
 * Run   : ./cow_demo                 (default demo)
 *         ./cow_demo -p 64 -w 16 -m 8 --pfn
 *         ./cow_demo --bench --sizes 16,64,256
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define MAGIC  0xC0FFEE0000000000ULL /* original content tag            */
#define PMAGIC 0xAAAA000000000000ULL /* tag written by the parent       */
#define CMAGIC 0xBBBB000000000000ULL /* tag written by the child        */
#define FAULT_TOLERANCE 3            /* allowed noise in fault counting */

static long PAGE;
static int pm_fd = -1;
static int show_pfn = 0;
static int failures = 0, checks = 0;

/* ------------------------------------------------------------------ utils */
static double now_ms(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec * 1e3 + t.tv_nsec / 1e6;
}

static long minflt(void)
{
    struct rusage ru;
    getrusage(RUSAGE_SELF, &ru);
    return ru.ru_minflt;
}

/* pagemap fd refers to the mm of the process that opened it, so every
 * process (parent AND child) must open its own after fork(). */
static void open_pagemap(void)
{
    if (pm_fd >= 0) close(pm_fd);
    pm_fd = open("/proc/self/pagemap", O_RDONLY);
}

typedef struct {
    int present, excl;
    uint64_t pfn;
} pginfo_t;

static int get_pginfo(const void *addr, pginfo_t *pi)
{
    uint64_t e;
    off_t off = (off_t)((uintptr_t)addr / (uintptr_t)PAGE) * 8;
    if (pm_fd < 0 || pread(pm_fd, &e, 8, off) != 8) return -1;
    pi->present = (int)((e >> 63) & 1);
    pi->excl = (int)((e >> 56) & 1);
    pi->pfn = e & ((1ULL << 55) - 1);
    return 0;
}

typedef struct {
    int shared, priv, absent, ok;
} mapstat_t;

/* Fill 'line' (n+1 bytes) with one char per page:
 *   '#' = shared with another process (COW-protected)
 *   'P' = private / exclusively mapped
 *   '.' = not present                                                    */
static mapstat_t scan(const char *region, int n, char *line)
{
    mapstat_t s = {0, 0, 0, 1};
    for (int i = 0; i < n; i++) {
        pginfo_t pi;
        if (get_pginfo(region + (size_t)i * PAGE, &pi) < 0) {
            s.ok = 0;
            line[i] = '?';
        } else if (!pi.present) {
            s.absent++;
            line[i] = '.';
        } else if (pi.excl) {
            s.priv++;
            line[i] = 'P';
        } else {
            s.shared++;
            line[i] = '#';
        }
    }
    line[n] = '\0';
    return s;
}

static void report(const char *who, const char *region, int n, const char *event)
{
    char *line = malloc((size_t)n + 1);
    mapstat_t s = scan(region, n, line);
    printf("  [%s pid=%d] %s\n", who, getpid(), event);
    if (!s.ok) {
        printf("      (pagemap unavailable on this system - map skipped)\n");
    } else {
        printf("      shared(COW)=%d  private=%d  not-present=%d\n", s.shared, s.priv, s.absent);
        for (int i = 0; i < n; i += 64)
            printf("      %.*s\n", (n - i) < 64 ? (n - i) : 64, line + i);
        if (show_pfn) {
            pginfo_t a, b;
            get_pginfo(region, &a);
            get_pginfo(region + (size_t)(n - 1) * PAGE, &b);
            if (a.pfn == 0 && b.pfn == 0)
                printf("      PFN hidden by kernel (run with sudo to see physical frames)\n");
            else
                printf("      PFN page[0]=0x%llx   page[%d]=0x%llx\n",
                       (unsigned long long)a.pfn, n - 1, (unsigned long long)b.pfn);
        }
    }
    fflush(stdout);
    free(line);
}

static void check(int cond, const char *what)
{
    checks++;
    if (!cond) failures++;
    printf("    [%s] %s\n", cond ? "PASS" : "FAIL", what);
    fflush(stdout);
}

/* ------------------------------------------------------- memory contents */
static void fill_region(char *r, int n)
{
    for (int i = 0; i < n; i++) {
        char *p = r + (size_t)i * PAGE;
        memset(p, (i & 0xff) ^ 0x5A, (size_t)PAGE);
        *(uint64_t *)p = MAGIC + (uint64_t)i;
    }
}

/* returns number of pages whose content differs from what this process
 * believes it wrote.  mod[i]!=0 -> this process rewrote page i itself. */
static int verify(const char *r, int n, const unsigned char *mod, uint64_t mymagic)
{
    int bad = 0;
    for (int i = 0; i < n; i++) {
        const char *p = r + (size_t)i * PAGE;
        uint64_t want = (mod[i] ? mymagic : MAGIC) + (uint64_t)i;
        if (*(const uint64_t *)p != want) bad++;
        else if (p[PAGE - 1] != (char)((i & 0xff) ^ 0x5A)) bad++;
    }
    return bad;
}

/* read one byte of every page; returns minor faults caused */
static long do_read(const char *r, int n)
{
    volatile unsigned long sum = 0;
    long f0 = minflt();
    for (int i = 0; i < n; i++) sum += (unsigned char)r[(size_t)i * PAGE];
    return minflt() - f0;
}

/* write pages [start, start+k); returns minor faults caused */
static long do_write(char *r, int start, int k, uint64_t magic)
{
    long f0 = minflt();
    for (int i = start; i < start + k; i++)
        *(volatile uint64_t *)(r + (size_t)i * PAGE) = magic + (uint64_t)i;
    return minflt() - f0;
}

/* ------------------------------------------------- parent <-> child talk */
typedef struct {
    char cmd; /* 'S' show, 'R' read all, 'W' write range, 'Q' quit */
    int start, k;
} msg_t;

typedef struct {
    long dflt;
    int bad;       /* pages with unexpected content in the child */
    int shared, priv;
} reply_t;

static int child_loop(char *region, int n, unsigned char *mod, int rfd, int wfd)
{
    open_pagemap();
    (void)minflt(); /* warm up: COW-fault our own stack page now */
    msg_t m;
    while (read(rfd, &m, sizeof m) == (ssize_t)sizeof m) {
        reply_t r = {0, 0, 0, 0};
        char *line = malloc((size_t)n + 1);
        switch (m.cmd) {
        case 'R':
            r.dflt = do_read(region, n);
            report("CHILD ", region, n, "after READING every page");
            break;
        case 'W':
            r.dflt = do_write(region, m.start, m.k, CMAGIC);
            for (int i = m.start; i < m.start + m.k; i++) mod[i] = 1;
            report("CHILD ", region, n, "after WRITING to its pages");
            break;
        case 'S':
            report("CHILD ", region, n, "inspection");
            break;
        case 'Q':
            free(line);
            return 0;
        }
        mapstat_t s = scan(region, n, line);
        r.shared = s.shared;
        r.priv = s.priv;
        r.bad = verify(region, n, mod, CMAGIC);
        free(line);
        if (write(wfd, &r, sizeof r) != (ssize_t)sizeof r) return 1;
    }
    return 0;
}

static reply_t ask(int wfd, int rfd, char cmd, int start, int k)
{
    msg_t m = {cmd, start, k};
    reply_t r;
    memset(&r, 0, sizeof r);
    if (write(wfd, &m, sizeof m) != (ssize_t)sizeof m ||
        read(rfd, &r, sizeof r) != (ssize_t)sizeof r) {
        fprintf(stderr, "child communication failed\n");
        exit(2);
    }
    return r;
}

/* ------------------------------------------------------------- the demo */
static int run_demo(int n, int kc, int mp)
{
    if (kc > n) kc = n;
    if (kc < 0) kc = 0;
    if (mp > n - kc) mp = n - kc;
    if (mp < 0) mp = 0;

    char *region = mmap(NULL, (size_t)n * PAGE, PROT_READ | PROT_WRITE,
                        MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (region == MAP_FAILED) { perror("mmap"); return 2; }
    madvise(region, (size_t)n * PAGE, MADV_NOHUGEPAGE); /* keep pages 4 KiB */
    fill_region(region, n);
    unsigned char *mod = calloc((size_t)n, 1);
    open_pagemap();

    printf("=========================================================\n");
    printf(" Copy-on-Write Memory Demonstrator\n");
    printf("   page size = %ld bytes, region = %d pages (%ld KiB)\n", PAGE, n, (long)n * PAGE / 1024);
    printf("   child will write pages 0..%d, parent will write pages %d..%d\n",
           kc - 1, kc, kc + mp - 1);
    printf("   map legend:  # shared (COW)   P private   . not present\n");
    printf("=========================================================\n\n");

    printf("STEP 1: parent allocates and fills memory (before fork)\n");
    report("PARENT", region, n, "before fork()");
    {
        char *line = malloc((size_t)n + 1);
        mapstat_t s = scan(region, n, line);
        free(line);
        if (s.ok) check(s.priv == n, "all pages are private to the parent before fork()");
    }

    printf("\nSTEP 2: fork() - no memory is copied, page tables are shared read-only\n");
    fflush(stdout);
    int p2c[2], c2p[2];
    if (pipe(p2c) || pipe(c2p)) { perror("pipe"); return 2; }
    fflush(stdout);
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 2; }
    if (pid == 0) {
        close(p2c[1]);
        close(c2p[0]);
        int rc = child_loop(region, n, mod, p2c[0], c2p[1]);
        fflush(stdout);
        _exit(rc);
    }
    close(p2c[0]);
    close(c2p[1]);
    int W = p2c[1], R = c2p[0];
    open_pagemap();

    reply_t r = ask(W, R, 'S', 0, 0);
    report("PARENT", region, n, "right after fork()");
    {
        char *line = malloc((size_t)n + 1);
        mapstat_t s = scan(region, n, line);
        free(line);
        if (s.ok) {
            check(s.shared == n, "parent: every page is now SHARED with the child");
            check(r.shared == n, "child : every page is SHARED with the parent");
        }
    }

    printf("\nSTEP 3: child only READS every page - nothing should be copied\n");
    fflush(stdout);
    r = ask(W, R, 'R', 0, 0);
    printf("    child minor page faults during read pass: %ld\n", r.dflt);
    check(r.dflt <= FAULT_TOLERANCE, "reading shared pages caused no (or negligible) page faults");
    check(r.shared == n, "child still shares all pages after reading");

    printf("\nSTEP 4: child WRITES %d page(s) - each first write = 1 COW fault + 1 page copy\n", kc);
    fflush(stdout);
    r = ask(W, R, 'W', 0, kc);
    printf("    child minor page faults during write pass: %ld (expected about %d)\n", r.dflt, kc);
    check(r.dflt >= kc && r.dflt <= kc + FAULT_TOLERANCE, "one COW fault per written page");
    check(r.priv == kc && r.shared == n - kc, "child: exactly the written pages became private");
    check(r.bad == 0, "child sees its own modifications and original data elsewhere");
    report("PARENT", region, n, "after the CHILD wrote (parent did nothing)");
    {
        char *line = malloc((size_t)n + 1);
        mapstat_t s = scan(region, n, line);
        free(line);
        if (s.ok) {
            /* the child's pages were copied away -> parent is now the only owner */
            check(s.priv == kc && s.shared == n - kc,
                  "parent: copied pages are no longer shared (it now owns the originals)");
        }
        check(verify(region, n, mod, PMAGIC) == 0,
              "ISOLATION: parent still sees ORIGINAL data - child's writes are invisible");
    }

    printf("\nSTEP 5: parent WRITES %d other page(s) - same mechanism in the other direction\n", mp);
    long pf = do_write(region, kc, mp, PMAGIC);
    for (int i = kc; i < kc + mp; i++) mod[i] = 1;
    printf("    parent minor page faults during write pass: %ld (expected about %d)\n", pf, mp);
    check(pf >= mp && pf <= mp + FAULT_TOLERANCE, "parent: one COW fault per written page");
    report("PARENT", region, n, "after the PARENT wrote");
    r = ask(W, R, 'S', 0, 0);
    {
        char *line = malloc((size_t)n + 1);
        mapstat_t s = scan(region, n, line);
        free(line);
        if (s.ok) {
            check(s.priv == kc + mp && s.shared == n - kc - mp,
                  "parent: written pages are private, rest still shared");
            check(r.priv == kc + mp && r.shared == n - kc - mp,
                  "child : sees same split (pages the parent copied are now exclusively the child's)");
        }
    }
    check(verify(region, n, mod, PMAGIC) == 0, "parent data correct (own writes + originals)");
    check(r.bad == 0, "ISOLATION: child still sees only its own writes + originals");

    printf("\nSTEP 6: cleanup\n");
    {
        msg_t q = {'Q', 0, 0}; /* child exits without replying */
        if (write(W, &q, sizeof q) != (ssize_t)sizeof q) perror("write");
    }
    int st = 0;
    waitpid(pid, &st, 0);
    close(W);
    close(R);
    check(WIFEXITED(st) && WEXITSTATUS(st) == 0, "child exited cleanly");

    printf("\n=========================================================\n");
    printf(" RESULT: %d/%d checks passed  ->  %s\n", checks - failures, checks,
           failures ? "FAILED" : "COPY-ON-WRITE VERIFIED");
    printf("=========================================================\n");
    munmap(region, (size_t)n * PAGE);
    free(mod);
    return failures ? 1 : 0;
}

/* ----------------------------------------------------------- benchmark */
static int run_bench(const char *sizes_csv, int csv)
{
    char *copy = strdup(sizes_csv), *save = NULL;
    if (csv)
        printf("size_mb,fork_ms,eager_copy_ms,cow_first_pass_ms,cow_us_per_page,second_pass_ms,second_us_per_page\n");
    else {
        printf("fork() latency vs. eager copy, and the cost of COW faults\n");
        printf("%-8s %-10s %-14s %-16s %-11s %-14s %-10s\n", "size(MB)", "fork(ms)",
               "eager-copy(ms)", "child 1st write", "us/page", "child 2nd write", "us/page");
    }
    for (char *tok = strtok_r(copy, ",", &save); tok; tok = strtok_r(NULL, ",", &save)) {
        long mb = atol(tok);
        if (mb <= 0) continue;
        size_t bytes = (size_t)mb << 20;
        size_t np = bytes / (size_t)PAGE;
        char *r = mmap(NULL, bytes, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (r == MAP_FAILED) { perror("mmap"); free(copy); return 2; }
        madvise(r, bytes, MADV_NOHUGEPAGE);
        memset(r, 0x11, bytes);

        int pfd[2];
        if (pipe(pfd)) { perror("pipe"); return 2; }
        fflush(stdout);
        double t0 = now_ms();
        pid_t pid = fork();
        if (pid == 0) {
            double a = now_ms();
            for (size_t p = 0; p < np; p++) r[p * (size_t)PAGE]++;
            double b = now_ms();
            for (size_t p = 0; p < np; p++) r[p * (size_t)PAGE]++;
            double c = now_ms();
            double res[2] = {b - a, c - b};
            if (write(pfd[1], res, sizeof res) < 0) _exit(1);
            _exit(0);
        }
        double fork_ms = now_ms() - t0;
        double res[2] = {0, 0};
        if (read(pfd[0], res, sizeof res) != (ssize_t)sizeof res) fprintf(stderr, "bench: short read\n");
        waitpid(pid, NULL, 0);
        close(pfd[0]);
        close(pfd[1]);

        char *d = mmap(NULL, bytes, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        madvise(d, bytes, MADV_NOHUGEPAGE);
        double t2 = now_ms();
        memcpy(d, r, bytes);
        double eager = now_ms() - t2;

        double us1 = res[0] * 1000.0 / (double)np, us2 = res[1] * 1000.0 / (double)np;
        if (csv)
            printf("%ld,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f\n", mb, fork_ms, eager, res[0], us1, res[1], us2);
        else
            printf("%-8ld %-10.3f %-14.3f %-16.3f %-11.3f %-14.3f %-10.3f\n", mb, fork_ms, eager,
                   res[0], us1, res[1], us2);
        fflush(stdout);
        munmap(r, bytes);
        munmap(d, bytes);
    }
    free(copy);
    return 0;
}

static void usage(const char *a0)
{
    printf("Usage: %s [options]\n"
           "  -p, --pages N        pages in the shared region (default 32)\n"
           "  -w, --write K        pages the CHILD writes (default 8)\n"
           "  -m, --parent-write M pages the PARENT writes after the child (default 4)\n"
           "      --pfn            show physical frame numbers (needs root)\n"
           "      --bench          run the fork()/COW timing benchmark instead\n"
           "      --sizes LIST     benchmark sizes in MB, comma separated (default 16,64,128)\n"
           "      --csv            benchmark output as CSV\n"
           "  -h, --help\n", a0);
}

int main(int argc, char **argv)
{
    int n = 32, kc = 8, mp = 4, bench = 0, csv = 0;
    const char *sizes = "16,64,128";
    static struct option lo[] = {{"pages", 1, 0, 'p'}, {"write", 1, 0, 'w'},
                                 {"parent-write", 1, 0, 'm'}, {"pfn", 0, 0, 1000},
                                 {"bench", 0, 0, 1001}, {"sizes", 1, 0, 1002},
                                 {"csv", 0, 0, 1003}, {"help", 0, 0, 'h'}, {0, 0, 0, 0}};
    int c;
    while ((c = getopt_long(argc, argv, "p:w:m:h", lo, NULL)) != -1) {
        switch (c) {
        case 'p': n = atoi(optarg); break;
        case 'w': kc = atoi(optarg); break;
        case 'm': mp = atoi(optarg); break;
        case 1000: show_pfn = 1; break;
        case 1001: bench = 1; break;
        case 1002: sizes = optarg; break;
        case 1003: csv = 1; break;
        default: usage(argv[0]); return c == 'h' ? 0 : 2;
        }
    }
    if (n < 1 || n > 1 << 20) { fprintf(stderr, "pages must be 1..1048576\n"); return 2; }
    PAGE = sysconf(_SC_PAGESIZE);
    return bench ? run_bench(sizes, csv) : run_demo(n, kc, mp);
}
