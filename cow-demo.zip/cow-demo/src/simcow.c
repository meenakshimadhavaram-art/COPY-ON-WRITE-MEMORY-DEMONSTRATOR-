/*
 * simcow.c - deterministic user-space simulation of Copy-on-Write.
 *
 * Models what the kernel does: per-process page tables pointing at physical
 * frames, a reference count per frame, and a "write-protected / COW" bit in
 * each page-table entry.  Works on any OS and makes the algorithm explicit:
 *
 *   fork()  : copy the PAGE TABLE only, refcount++ on every frame, mark all
 *             entries read-only (COW).
 *   read    : follow the entry, no change.
 *   write   : if entry is COW:
 *               refcount > 1  -> allocate new frame, copy data, refcount--,
 *                                point entry at the copy      (a "COW copy")
 *               refcount == 1 -> last owner: just make it writable (no copy)
 *
 * Exit status is non-zero if any built-in assertion fails (used by tests).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NPAGES 4
#define MAXFRAMES 32
#define MAXPROCS 4

typedef struct { int frame; int cow; } pte_t;
typedef struct { int alive; pte_t pt[NPAGES]; } proc_t;

static char frames[MAXFRAMES][16];
static int refcnt[MAXFRAMES];
static int nframes = 0;
static proc_t procs[MAXPROCS];
static int copies = 0, fails = 0;

static int alloc_frame(const char *data)
{
    for (int f = 0; f < MAXFRAMES; f++)
        if (refcnt[f] == 0) {
            strncpy(frames[f], data, 15);
            frames[f][15] = 0;
            refcnt[f] = 1;
            nframes++;
            return f;
        }
    fprintf(stderr, "out of frames\n");
    exit(2);
}

static void dump(const char *title)
{
    printf("\n--- %s\n", title);
    for (int p = 0; p < MAXPROCS; p++) {
        if (!procs[p].alive) continue;
        printf("  P%d page table: ", p);
        for (int i = 0; i < NPAGES; i++)
            printf("[%d->F%d%s] ", i, procs[p].pt[i].frame, procs[p].pt[i].cow ? " COW" : "    ");
        printf("\n");
    }
    printf("  frames in use: %d  | ", nframes);
    for (int f = 0; f < MAXFRAMES; f++)
        if (refcnt[f]) printf("F%d=\"%s\"(ref %d) ", f, frames[f], refcnt[f]);
    printf("\n");
}

static void expect(int cond, const char *msg)
{
    printf("  %s %s\n", cond ? "[PASS]" : "[FAIL]", msg);
    if (!cond) fails++;
}

static int sim_fork(int parent)
{
    int c = 0;
    while (procs[c].alive) c++;
    procs[c].alive = 1;
    for (int i = 0; i < NPAGES; i++) {
        procs[c].pt[i] = procs[parent].pt[i];  /* share the frame */
        procs[c].pt[i].cow = 1;
        procs[parent].pt[i].cow = 1;            /* both become COW */
        refcnt[procs[c].pt[i].frame]++;
    }
    return c;
}

static const char *sim_read(int p, int page) { return frames[procs[p].pt[page].frame]; }

static void sim_write(int p, int page, const char *data)
{
    pte_t *e = &procs[p].pt[page];
    if (e->cow) {
        if (refcnt[e->frame] > 1) {           /* shared -> real copy */
            int nf = alloc_frame(frames[e->frame]);
            refcnt[e->frame]--;
            e->frame = nf;
            copies++;
        }
        e->cow = 0;                            /* now private + writable */
    }
    strncpy(frames[e->frame], data, 15);
}

int main(void)
{
    printf("Copy-on-Write simulation (4 pages, frames F0..)\n");
    procs[0].alive = 1;
    const char *init[NPAGES] = {"A", "B", "C", "D"};
    for (int i = 0; i < NPAGES; i++) { procs[0].pt[i].frame = alloc_frame(init[i]); procs[0].pt[i].cow = 0; }
    dump("P0 created with pages A B C D");
    expect(nframes == 4, "4 frames allocated for P0");

    int c = sim_fork(0);
    dump("after P0 forks P1: page tables copied, NO new frames");
    expect(nframes == 4, "fork() allocated zero new frames");
    expect(procs[0].pt[0].frame == procs[c].pt[0].frame, "P0 and P1 map the same frame");

    expect(strcmp(sim_read(c, 2), "C") == 0, "P1 reads page 2 = C");
    expect(copies == 0 && nframes == 4, "read caused no copy");

    sim_write(c, 1, "B'");
    dump("P1 writes page 1 -> COW copy");
    expect(copies == 1 && nframes == 5, "exactly one frame copied");
    expect(strcmp(sim_read(0, 1), "B") == 0, "P0 still sees B (isolation)");
    expect(strcmp(sim_read(c, 1), "B'") == 0, "P1 sees B'");

    sim_write(0, 1, "B0");
    dump("P0 writes page 1 -> it is now sole owner, NO copy needed");
    expect(copies == 1 && nframes == 5, "last-owner optimisation: reused frame, no copy");
    expect(strcmp(sim_read(c, 1), "B'") == 0, "P1 unaffected");

    sim_write(0, 3, "D0");
    sim_write(c, 3, "D1");
    dump("both write page 3: first copies, second reuses");
    expect(copies == 2 && nframes == 6, "total copies = 2");
    expect(strcmp(sim_read(0, 3), "D0") == 0 && strcmp(sim_read(c, 3), "D1") == 0, "pages 3 diverged correctly");
    expect(strcmp(sim_read(0, 0), "A") == 0 && procs[0].pt[0].frame == procs[c].pt[0].frame,
           "untouched page 0 is STILL shared (memory saved)");

    printf("\nSummary: %d frames used instead of %d (no-COW), %d COW copies made.\n",
           nframes, 2 * NPAGES, copies);
    printf("%s\n", fails ? "SIMULATION FAILED" : "SIMULATION OK");
    return fails ? 1 : 0;
}
