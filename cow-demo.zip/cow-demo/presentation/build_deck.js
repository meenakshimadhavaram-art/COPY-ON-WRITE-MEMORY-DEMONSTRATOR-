const pptxgen = require("pptxgenjs");
const { applyTheme } = require("/mnt/skills/public/pptx/scripts/apply_theme.js");

const THEME = {
  name: "COW Demo",
  headFontFace: "Cambria",
  bodyFontFace: "Calibri",
  colors: {
    dk1: "0B1B2E", lt1: "FFFFFF", dk2: "1F3A5A", lt2: "EEF3F8",
    accent1: "0F9D8F",  // teal  = private page
    accent2: "F2A33A",  // amber = shared page
    accent3: "4C6EF5", accent4: "E5484D", accent5: "6B7C93", accent6: "2FB171",
    hlink: "0F9D8F", folHlink: "6B7C93",
  },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE"; // 13.33 x 7.5
pres.title = "Copy-on-Write Memory Demonstrator";
pres.author = "Project Team";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

pres.defineSlideMaster({
  title: "TITLE",
  background: { color: C.text1 },
  objects: [],
  slideNumber: undefined,
});
pres.defineSlideMaster({
  title: "CONTENT",
  background: { color: C.background1 },
  margin: [0.5, 0.6, 0.5, 0.6],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.6, y: 0.4, w: 12.1, h: 0.9,
        fontSize: 34, bold: true, color: C.text2, align: "left", valign: "middle", margin: 0 }, text: "" } },
    { text: { text: "Copy-on-Write Memory Demonstrator", options: { x: 0.6, y: 7.05, w: 6, h: 0.3, fontSize: 10,
        color: C.accent5, margin: 0, isTextBox: true } } },
  ],
  slideNumber: { x: 12.2, y: 7.05, w: 0.6, h: 0.3, fontSize: 10, color: C.accent5, align: "right" },
});

const card = (s, x, y, w, h, name, fill) =>
  s.addShape(pres.ShapeType.roundRect, { x, y, w, h, rectRadius: 0.12, fill: { color: fill || C.background2 },
    line: { color: fill || C.background2, width: 0 }, objectName: name });
const txt = (s, t, o) => s.addText(t, Object.assign({ isTextBox: true, margin: 0, valign: "top", color: C.text1, fontSize: 16 }, o));

// ---------- 1 Title
{
  const s = pres.addSlide({ masterName: "TITLE" });
  txt(s, "OPERATING SYSTEMS PROJECT", { x: 0.9, y: 1.3, w: 8, h: 0.4, fontSize: 14, color: C.accent2, bold: true, charSpacing: 4 });
  txt(s, "Copy-on-Write\nMemory Demonstrator", { x: 0.9, y: 1.9, w: 8.2, h: 2.4, fontSize: 54, bold: true, color: C.background1, fontFace: "Cambria", valign: "top" });
  txt(s, "How fork() shares memory and copies a page only when someone writes to it", { x: 0.9, y: 4.5, w: 7.6, h: 0.9, fontSize: 20, color: C.background2 });
  txt(s, "Team: <names / roll numbers>   |   Guide: <name>   |   <date>", { x: 0.9, y: 6.4, w: 9, h: 0.4, fontSize: 14, color: C.accent5 });
  // motif: page grid
  const x0 = 9.6, y0 = 1.5, cs = 0.62, gap = 0.12;
  for (let r = 0; r < 5; r++) for (let c = 0; c < 4; c++) {
    const priv = (r * 4 + c) < 7;
    s.addShape(pres.ShapeType.roundRect, { x: x0 + c * (cs + gap), y: y0 + r * (cs + gap), w: cs, h: cs, rectRadius: 0.08,
      fill: { color: priv ? C.accent1 : C.accent2 }, line: { color: priv ? C.accent1 : C.accent2, width: 0 }, objectName: `page-${r}-${c}` });
  }
  txt(s, "teal = private    amber = shared", { x: 9.6, y: 5.55, w: 3.6, h: 0.3, fontSize: 12, color: C.background2 });
  s.addNotes("Introduce the project and team. The tile grid is our motif: amber pages are shared between parent and child, teal pages are private after a copy.");
}

// ---------- 2 Problem
{
  const s = pres.addSlide({ masterName: "CONTENT" });
  s.addText("The problem: fork() looks expensive but isn't", { placeholder: "title" });
  card(s, 0.6, 1.7, 5.9, 4.9, "q-card");
  txt(s, "The puzzle", { x: 0.95, y: 2.0, w: 5.2, h: 0.4, fontSize: 22, bold: true, color: C.text2 });
  txt(s, [
    { text: "fork() must give the child a full copy of the parent's memory.", options: { bullet: true, breakLine: true } },
    { text: "Yet it returns in ~1 ms even for hundreds of MB.", options: { bullet: true, breakLine: true } },
    { text: "Copying 256 MB eagerly takes ~140 ms.", options: { bullet: true } },
  ], { x: 0.95, y: 2.6, w: 5.2, h: 2.2, fontSize: 18, paraSpaceAfter: 10 });
  txt(s, "Goal: build a system that makes the hidden mechanism visible and measurable.", { x: 0.95, y: 5.2, w: 5.2, h: 1.1, fontSize: 18, bold: true, color: C.accent1 });
  const items = [
    ["1", "Show memory is SHARED after fork()"],
    ["2", "Show reads copy nothing"],
    ["3", "Show a write copies ONLY that page"],
    ["4", "Prove the other process is unaffected"],
  ];
  items.forEach((it, i) => {
    const y = 1.7 + i * 1.28;
    s.addShape(pres.ShapeType.ellipse, { x: 7.0, y: y + 0.12, w: 0.8, h: 0.8, fill: { color: C.accent1 }, line: { color: C.accent1, width: 0 }, objectName: `goal-dot-${i}` });
    txt(s, it[0], { x: 7.0, y: y + 0.12, w: 0.8, h: 0.8, fontSize: 26, bold: true, color: C.background1, align: "center", valign: "middle" });
    txt(s, it[1], { x: 8.1, y: y + 0.12, w: 4.6, h: 0.8, fontSize: 20, valign: "middle" });
  });
  s.addNotes("State the problem statement. Four demonstration goals map directly to the four steps of our demo.");
}

// ---------- 3 Concept
{
  const s = pres.addSlide({ masterName: "CONTENT" });
  s.addText("Copy-on-Write in four moves", { placeholder: "title" });
  const steps = [
    ["fork()", "Copy only the page tables. Every frame's reference count becomes 2. Entries marked read-only (COW)."],
    ["Read", "Follows the shared mapping. No fault, no copy."],
    ["Write", "Protection fault. Kernel checks the refcount of the frame."],
    ["Copy", "refcount > 1: allocate frame, copy 4 KiB, remap writable. refcount = 1: just make writable."],
  ];
  steps.forEach((st, i) => {
    const x = 0.6 + i * 3.1;
    card(s, x, 1.8, 2.9, 3.6, `move-card-${i}`);
    s.addShape(pres.ShapeType.ellipse, { x: x + 0.3, y: 2.1, w: 0.7, h: 0.7, fill: { color: i === 3 ? C.accent2 : C.accent1 }, line: { color: C.background2, width: 0 }, objectName: `move-dot-${i}` });
    txt(s, String(i + 1), { x: x + 0.3, y: 2.1, w: 0.7, h: 0.7, fontSize: 22, bold: true, color: C.background1, align: "center", valign: "middle" });
    txt(s, st[0], { x: x + 0.3, y: 3.0, w: 2.4, h: 0.5, fontSize: 24, bold: true, color: C.text2, fontFace: "Cambria" });
    txt(s, st[1], { x: x + 0.3, y: 3.6, w: 2.4, h: 1.7, fontSize: 15 });
  });
  card(s, 0.6, 5.75, 12.1, 0.95, "benefit-strip", C.text2);
  txt(s, "Result: fast fork, less memory, and work is paid for only on pages that actually change.", { x: 0.9, y: 5.75, w: 11.5, h: 0.95, fontSize: 18, bold: true, color: C.background1, valign: "middle" });
  s.addNotes("Walk the four moves. Emphasise the last-owner optimisation: if the refcount is already 1 no copy is needed.");
}

// ---------- 4 System design (diagram)
{
  const s = pres.addSlide({ masterName: "CONTENT" });
  s.addText("System design: page tables, frames and reference counts", { placeholder: "title" });
  // columns
  const pX = 0.9, fX = 5.0, cX = 9.1, cw = 3.2, rh = 0.62, y0 = 2.35, gap = 0.2;
  txt(s, "Parent page table", { x: pX, y: 1.7, w: cw, h: 0.4, fontSize: 18, bold: true, color: C.text2, align: "center" });
  txt(s, "Physical frames (refcount)", { x: fX, y: 1.7, w: cw, h: 0.4, fontSize: 18, bold: true, color: C.text2, align: "center" });
  txt(s, "Child page table", { x: cX, y: 1.7, w: cw, h: 0.4, fontSize: 18, bold: true, color: C.text2, align: "center" });
  const rowY = (i) => y0 + i * (rh + gap);
  const frames = [["F0  \"A\"", "2", true], ["F1  \"B\"", "1", false], ["F2  \"C\"", "2", true], ["F3  \"D\"", "2", true], ["F4  \"B'\"", "1", false]];
  frames.forEach((f, i) => {
    s.addShape(pres.ShapeType.roundRect, { x: fX, y: rowY(i), w: cw, h: rh, rectRadius: 0.08, fill: { color: f[2] ? C.accent2 : C.accent1 }, line: { color: C.background1, width: 0 }, objectName: `frame-${i}` });
    txt(s, `${f[0]}   ref ${f[1]}`, { x: fX, y: rowY(i), w: cw, h: rh, fontSize: 16, bold: true, color: C.text1, align: "center", valign: "middle" });
  });
  const parentMap = [0, 1, 2, 3], childMap = [0, 4, 2, 3];
  const cell = (x, i, f, who) => {
    s.addShape(pres.ShapeType.roundRect, { x, y: rowY(i), w: cw, h: rh, rectRadius: 0.08, fill: { color: C.background2 }, line: { color: C.accent5, width: 1 }, objectName: `${who}-pte-${i}` });
    txt(s, `page ${i} -> F${f}`, { x, y: rowY(i), w: cw, h: rh, fontSize: 16, align: "center", valign: "middle" });
  };
  parentMap.forEach((f, i) => cell(pX, i, f, "parent"));
  childMap.forEach((f, i) => cell(cX, i, f, "child"));
  const link = (x1, y1, x2, y2, col, name) => {
    const flipV = y2 < y1;
    s.addShape(pres.ShapeType.line, { x: Math.min(x1, x2), y: Math.min(y1, y2), w: Math.abs(x2 - x1), h: Math.abs(y2 - y1), flipV,
      line: { color: col, width: 2 }, objectName: name });
  };
  parentMap.forEach((f, i) => link(pX + cw, rowY(i) + rh / 2, fX, rowY(f) + rh / 2, C.accent5, `plink-${i}`));
  childMap.forEach((f, i) => link(fX + cw, rowY(f) + rh / 2, cX, rowY(i) + rh / 2, C.accent5, `clink-${i}`));
  txt(s, "State shown: child has written page 1. Pages 0, 2, 3 are still shared (amber, ref 2). Page 1 now has a private copy per process (teal, ref 1).",
    { x: 0.9, y: 6.2, w: 11.5, h: 0.6, fontSize: 15, color: C.accent5 });
  s.addNotes("This is exactly what src/simcow.c simulates and what the kernel does. Amber = shared frames, teal = private frames.");
}

// ---------- 5 Implementation approach
{
  const s = pres.addSlide({ masterName: "CONTENT" });
  s.addText("Implementation: a six-step controlled scenario", { placeholder: "title" });
  const rows = [
    ["1", "Allocate", "mmap N pages, fill each with a known pattern", "all private"],
    ["2", "fork()", "child created; page tables copied", "all shared"],
    ["3", "Child reads", "sums one byte per page", "0 faults, still shared"],
    ["4", "Child writes K", "first write to each page", "K faults, K private"],
    ["5", "Parent writes M", "other pages, other direction", "M faults, K+M private"],
    ["6", "Verify + exit", "content check in both processes", "isolation proven"],
  ];
  const hdr = { fontSize: 14, bold: true, color: C.background1, fill: { color: C.text2 }, valign: "middle" };
  const body = (extra) => Object.assign({ fontSize: 15, color: C.text1, valign: "middle" }, extra || {});
  const trows = [[
    { text: "#", options: hdr }, { text: "Action", options: hdr }, { text: "What happens", options: hdr }, { text: "Expected observation", options: hdr },
  ]];
  rows.forEach((r, i) => {
    const f = { fill: { color: i % 2 ? C.background1 : C.background2 } };
    trows.push([
      { text: r[0], options: body(Object.assign({ bold: true, color: C.accent1 }, f)) },
      { text: r[1], options: body(Object.assign({ bold: true }, f)) },
      { text: r[2], options: body(f) },
      { text: r[3], options: body(f) },
    ]);
  });
  s.addTable(trows, { x: 0.6, y: 1.65, w: 12.1, colW: [0.6, 2.6, 5.0, 3.9], rowH: 0.52, border: { type: "none" }, margin: [0.05, 0.12, 0.05, 0.12], objectName: "steps-table" });
  txt(s, "Three independent evidence sources: /proc/self/pagemap (shared vs private, PFN)  |  getrusage page-fault counter  |  content verification",
    { x: 0.6, y: 5.75, w: 12.1, h: 0.8, fontSize: 16, bold: true, color: C.accent1 });
  s.addNotes("Parent and child synchronise through a command pipe so output order is deterministic. Each process opens its own /proc/self/pagemap because the fd is bound to the opener's address space.");
}

// ---------- 6 Technologies
{
  const s = pres.addSlide({ masterName: "CONTENT" });
  s.addText("Technologies and components", { placeholder: "title" });
  const t = [
    ["C11 + POSIX", "fork, pipe, mmap, madvise, waitpid"],
    ["Linux /proc", "pagemap bits: present, exclusive, PFN"],
    ["getrusage", "minor page-fault counter"],
    ["Make + Bash", "build and 10-case test suite"],
    ["simcow.c", "user-space page-table simulator"],
    ["Git / GitHub", "source, README, report, slides"],
  ];
  t.forEach((it, i) => {
    const col = i % 3, row = Math.floor(i / 3);
    const x = 0.6 + col * 4.1, y = 1.8 + row * 2.4;
    card(s, x, y, 3.9, 2.1, `tech-card-${i}`);
    s.addShape(pres.ShapeType.ellipse, { x: x + 0.3, y: y + 0.3, w: 0.5, h: 0.5, fill: { color: i % 2 ? C.accent2 : C.accent1 }, line: { color: C.background2, width: 0 }, objectName: `tech-dot-${i}` });
    txt(s, it[0], { x: x + 0.3, y: y + 0.95, w: 3.3, h: 0.45, fontSize: 22, bold: true, color: C.text2, fontFace: "Cambria" });
    txt(s, it[1], { x: x + 0.3, y: y + 1.45, w: 3.3, h: 0.5, fontSize: 15 });
  });
  s.addNotes("No third-party libraries. Everything is standard C and the Linux kernel's own interfaces.");
}

// ---------- 7 Live map evolution
{
  const s = pres.addSlide({ masterName: "CONTENT" });
  s.addText("What the demo shows: the page map at each step", { placeholder: "title" });
  const rows = [
    ["Before fork", 32, "0 faults"], ["After fork()", 0, "0 copies"], ["Child reads all", 0, "0 faults"],
    ["Child writes 8", 8, "8 faults"], ["Parent writes 4", 12, "+4 faults"],
  ];
  const cs = 0.26, gp = 0.03, x0 = 3.2;
  rows.forEach((r, i) => {
    const y = 1.85 + i * 0.92;
    txt(s, r[0], { x: 0.6, y, w: 2.5, h: 0.32, fontSize: 18, bold: true, color: C.text2 });
    txt(s, r[2], { x: 0.6, y: y + 0.34, w: 2.5, h: 0.3, fontSize: 13, color: C.accent5 });
    for (let c = 0; c < 32; c++) {
      const priv = c < r[1];
      s.addShape(pres.ShapeType.rect, { x: x0 + c * (cs + gp), y, w: cs, h: 0.6, fill: { color: priv ? C.accent1 : C.accent2 }, line: { color: priv ? C.accent1 : C.accent2, width: 0 }, objectName: `map-${i}-${c}` });
    }
  });
  s.addShape(pres.ShapeType.rect, { x: 3.2, y: 6.5, w: 0.26, h: 0.26, fill: { color: C.accent1 }, line: { color: C.accent1, width: 0 }, objectName: "legend-private" });
  txt(s, "private to one process", { x: 3.6, y: 6.47, w: 3, h: 0.32, fontSize: 14 });
  s.addShape(pres.ShapeType.rect, { x: 6.8, y: 6.5, w: 0.26, h: 0.26, fill: { color: C.accent2 }, line: { color: C.accent2, width: 0 }, objectName: "legend-shared" });
  txt(s, "shared by parent and child (COW)", { x: 7.2, y: 6.47, w: 4.5, h: 0.32, fontSize: 14 });
  s.addNotes("Recorded from a real run: results/demo_default.txt. Each cell is one 4 KiB page. After the parent writes, both processes report 12 private / 20 shared.");
}

// ---------- 8 Testing
{
  const s = pres.addSlide({ masterName: "CONTENT" });
  s.addText("Testing and validation: 10/10 tests, 16 checks per run", { placeholder: "title" });
  const tests = [
    ["T1", "Default 32 pages"], ["T2", "Child writes 0 (pure sharing)"], ["T3", "Child writes all (worst case)"],
    ["T4", "Single-page region"], ["T5", "1024 pages (4 MiB)"], ["T6", "Parent-heavy writes"],
    ["T7", "Simulator assertions"], ["T8", "Benchmark CSV output"], ["T9", "Invalid input rejected"], ["T10", "5 repeated runs"],
  ];
  tests.forEach((t, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = 0.6 + col * 4.05, y = 1.75 + row * 0.98;
    card(s, x, y, 3.85, 0.82, `test-card-${i}`);
    txt(s, t[0], { x: x + 0.2, y, w: 0.7, h: 0.82, fontSize: 16, bold: true, color: C.accent1, valign: "middle" });
    txt(s, t[1], { x: x + 0.9, y, w: 2.85, h: 0.82, fontSize: 14, valign: "middle" });
  });
  card(s, 8.9, 1.75, 3.8, 4.7, "checks-card", C.text2);
  txt(s, "Checked every run", { x: 9.2, y: 2.0, w: 3.3, h: 0.4, fontSize: 18, bold: true, color: C.accent2 });
  txt(s, [
    { text: "page states after each step", options: { bullet: true, breakLine: true } },
    { text: "fault count = pages written", options: { bullet: true, breakLine: true } },
    { text: "data isolation in both processes", options: { bullet: true, breakLine: true } },
    { text: "clean child exit", options: { bullet: true } },
  ], { x: 9.2, y: 2.6, w: 3.3, h: 3.2, fontSize: 16, color: C.background1, paraSpaceAfter: 10 });
  s.addNotes("make test runs everything. Non-zero exit code on any failure, so it can run in CI.");
}

// ---------- 9 Results: demo numbers
{
  const s = pres.addSlide({ masterName: "CONTENT" });
  s.addText("Results: the kernel behaves exactly as predicted", { placeholder: "title" });
  const stats = [
    ["0", "page faults when the child reads all pages"],
    ["8 = 8", "faults equal pages written by the child"],
    ["0 copies", "made by fork() itself: 32/32 pages shared"],
    ["16/16", "internal checks passed in the default run"],
  ];
  stats.forEach((st, i) => {
    const x = 0.6 + i * 3.1;
    card(s, x, 1.8, 2.9, 2.3, `stat-card-${i}`);
    txt(s, st[0], { x: x + 0.2, y: 2.0, w: 2.5, h: 0.9, fontSize: 40, bold: true, color: C.accent1, fontFace: "Cambria", valign: "middle" });
    txt(s, st[1], { x: x + 0.2, y: 3.0, w: 2.5, h: 1.0, fontSize: 15 });
  });
  card(s, 0.6, 4.4, 12.1, 2.3, "pfn-card", C.text2);
  txt(s, "Physical proof (run as root with --pfn)", { x: 0.95, y: 4.6, w: 11, h: 0.4, fontSize: 18, bold: true, color: C.accent2 });
  txt(s, [
    { text: "page 0 before child writes:  parent PFN 0x1189c6  =  child PFN 0x1189c6  (same physical frame)", options: { breakLine: true } },
    { text: "page 0 after child writes:   parent keeps 0x1189c6;  child moves to 0x1189e5  (private copy)", options: { breakLine: true } },
    { text: "page 15 never written:       0x1189e8 in both processes  (still shared)" },
  ], { x: 0.95, y: 5.15, w: 11.4, h: 1.4, fontSize: 16, color: C.background1, fontFace: "Calibri", paraSpaceAfter: 6 });
  s.addNotes("Numbers come from results/demo_pfn.txt and results/demo_default.txt.");
}

// ---------- 10 Benchmark chart
{
  const s = pres.addSlide({ masterName: "CONTENT" });
  s.addText("Benchmark: fork() is 50-80x cheaper than an eager copy", { placeholder: "title" });
  const labels = ["16 MB: 0.13 vs 6.5", "64 MB: 0.51 vs 30.5", "128 MB: 0.88 vs 68.6", "256 MB: 1.8 vs 139.6"];
  s.addChart(pres.charts.BAR, [
    { name: "fork() (ms)", labels, values: [0.127, 0.511, 0.875, 1.802] },
    { name: "eager memcpy (ms)", labels, values: [6.484, 30.541, 68.563, 139.586] },
  ], {
    x: 0.6, y: 1.6, w: 7.7, h: 5.2, barDir: "col", barGapWidthPct: 60,
    chartColors: ["0F9D8F", "F2A33A"],
    showTitle: true, title: "Time in ms, log scale (labels: fork vs eager copy)", titleFontSize: 14, titleColor: "1F3A5A", titleFontFace: "+mn-lt",
    showValue: false,
    valAxisLogScaleBase: 10, valAxisMinVal: 0.01, valAxisMaxVal: 1000,
    catAxisLabelColor: "1F3A5A", catAxisLabelFontSize: 12, catAxisLabelFontFace: "+mn-lt",
    valAxisLabelColor: "6B7C93", valAxisLabelFontSize: 12, valAxisLabelFontFace: "+mn-lt",
    valGridLine: { color: "D9E2EC", size: 0.75 }, catGridLine: { style: "none" },
    showLegend: true, legendPos: "b", legendFontSize: 13, legendColor: "1F3A5A", legendFontFace: "+mn-lt",
  });
  card(s, 8.7, 1.8, 4.0, 2.2, "cost-card");
  txt(s, "~2.5 us", { x: 8.95, y: 1.95, w: 3.5, h: 0.9, fontSize: 44, bold: true, color: C.accent1, fontFace: "Cambria", valign: "middle" });
  txt(s, "per page for the first write (fault + 4 KiB copy)", { x: 8.95, y: 2.9, w: 3.5, h: 0.9, fontSize: 15 });
  card(s, 8.7, 4.3, 4.0, 2.2, "second-card");
  txt(s, "~0.01 us", { x: 8.95, y: 4.45, w: 3.5, h: 0.9, fontSize: 44, bold: true, color: C.accent2, fontFace: "Cambria", valign: "middle" });
  txt(s, "per page for the second write: the copy is already private", { x: 8.95, y: 5.4, w: 3.5, h: 0.9, fontSize: 15 });
  s.addNotes("Source: results/bench.csv, 1 vCPU VM. Trade-off: if every page is written, COW costs slightly more than an eager copy; it wins when only a fraction of pages change, e.g. fork+exec.");
}

// ---------- 11 Impact
{
  const s = pres.addSlide({ masterName: "CONTENT" });
  s.addText("Impact and real-world uses", { placeholder: "title" });
  const u = [
    ["Shells and servers", "fork()+exec() copies almost nothing"],
    ["Redis / databases", "background snapshots of live memory"],
    ["Containers and VMs", "shared image layers, cheap snapshots"],
    ["MAP_PRIVATE files", "private edits without touching the file"],
    ["Memory savings", "identical pages stay as one physical copy"],
    ["Teaching tool", "makes virtual memory observable"],
  ];
  u.forEach((it, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = 0.6 + col * 6.15, y = 1.75 + row * 1.6;
    card(s, x, y, 5.95, 1.4, `impact-card-${i}`);
    s.addShape(pres.ShapeType.ellipse, { x: x + 0.3, y: y + 0.4, w: 0.6, h: 0.6, fill: { color: i % 2 ? C.accent2 : C.accent1 }, line: { color: C.background2, width: 0 }, objectName: `impact-dot-${i}` });
    txt(s, it[0], { x: x + 1.15, y: y + 0.25, w: 4.6, h: 0.45, fontSize: 20, bold: true, color: C.text2, fontFace: "Cambria" });
    txt(s, it[1], { x: x + 1.15, y: y + 0.78, w: 4.6, h: 0.45, fontSize: 15 });
  });
  s.addNotes("Connect to real systems the audience knows.");
}

// ---------- 12 Team + limitations
{
  const s = pres.addSlide({ masterName: "CONTENT" });
  s.addText("Team roles, limitations and future work", { placeholder: "title" });
  card(s, 0.6, 1.7, 7.0, 5.0, "team-card");
  txt(s, "Team contributions (edit names)", { x: 0.9, y: 1.95, w: 6.4, h: 0.4, fontSize: 20, bold: true, color: C.text2 });
  txt(s, [
    { text: "Member 1: demo engine, fork and pipe orchestration", options: { bullet: true, breakLine: true } },
    { text: "Member 2: pagemap / getrusage observer, PFN", options: { bullet: true, breakLine: true } },
    { text: "Member 3: tests, benchmark, results", options: { bullet: true, breakLine: true } },
    { text: "Member 4: simulator, report, README", options: { bullet: true, breakLine: true } },
    { text: "Member 5: slides, live demo, GitHub", options: { bullet: true } },
  ], { x: 0.9, y: 2.6, w: 6.4, h: 3.8, fontSize: 17, paraSpaceAfter: 12 });
  card(s, 7.9, 1.7, 4.8, 5.0, "future-card", C.text2);
  txt(s, "Limitations / next steps", { x: 8.2, y: 1.95, w: 4.2, h: 0.4, fontSize: 20, bold: true, color: C.accent2 });
  txt(s, [
    { text: "Linux-only observer", options: { bullet: true, breakLine: true } },
    { text: "Huge-page (2 MiB) COW", options: { bullet: true, breakLine: true } },
    { text: "File-backed MAP_PRIVATE", options: { bullet: true, breakLine: true } },
    { text: "Multi-threaded parents", options: { bullet: true, breakLine: true } },
    { text: "GUI page-map viewer", options: { bullet: true } },
  ], { x: 8.2, y: 2.6, w: 4.2, h: 3.8, fontSize: 17, color: C.background1, paraSpaceAfter: 12 });
  s.addNotes("Each member should be able to explain their own module. See docs/TEAM.md.");
}

// ---------- 13 Closing
{
  const s = pres.addSlide({ masterName: "TITLE" });
  txt(s, "fork() copies page tables.\nWrites copy pages.", { x: 0.9, y: 1.8, w: 11.5, h: 2.2, fontSize: 48, bold: true, color: C.background1, fontFace: "Cambria" });
  txt(s, "Live demo next: ./cow_demo   |   make test   |   ./cow_demo --bench", { x: 0.9, y: 4.4, w: 11.5, h: 0.5, fontSize: 20, color: C.accent2 });
  txt(s, "Thank you  -  Questions?", { x: 0.9, y: 5.5, w: 8, h: 0.5, fontSize: 24, color: C.background2 });
  txt(s, "github.com/<your-team>/cow-demo", { x: 0.9, y: 6.4, w: 8, h: 0.4, fontSize: 14, color: C.accent5 });
}

(async () => {
  await pres.writeFile({ fileName: "COW_Demonstrator.pptx" });
  await applyTheme("COW_Demonstrator.pptx", THEME);
  console.log("done");
})();
