# Copy-on-Write Memory Demonstrator

A small, self-contained C project that **proves with real kernel data** how Linux shares memory
between a parent and child after `fork()` and copies a page **only when one of them writes to it**.

| Component | File | What it does |
|-----------|------|--------------|
| Live demonstrator | `src/cow_demo.c` | Runs a 6-step fork/read/write scenario, draws a per-page map of shared vs. private pages, counts page faults, verifies data isolation, prints PASS/FAIL |
| Benchmark | `cow_demo --bench` | Compares `fork()` latency with an eager `memcpy`, and measures the cost of a COW fault |
| User-space simulator | `src/simcow.c` | Page tables + frame reference counts, showing the algorithm itself (works on any OS) |
| Test suite | `tests/run_tests.sh` | 10 automated scenarios (`make test`) |
| Docs | `docs/` | Project report, demo script and viva Q&A, team roles |

## How the proof works

After `fork()` the kernel copies only the page tables and marks every writable private page read-only.
We observe the result through three independent sources:

1. `/proc/self/pagemap` - per page: *present* (bit 63) and *exclusively mapped* (bit 56). A page mapped by
   two processes is "shared"; once it is copied it becomes "private". With root, the physical frame number
   (PFN, bits 0-54) is shown too: same PFN = same physical memory.
2. `getrusage().ru_minflt` - minor page-fault counter. Reading shared pages = 0 faults;
   writing N shared pages = N faults (one COW fault per page).
3. Content checks - every page of both processes is re-verified, proving that one process never sees the
   other's writes.

## Requirements

* Linux (kernel >= 4.2 for the pagemap "exclusive" bit), x86-64 or ARM64
* `gcc` (or any C11 compiler) and `make`
* No root needed. Run with `sudo` only if you want to see physical frame numbers (`--pfn`).
* Not supported: macOS/Windows (no `/proc`); use `simcow` there.
* WSL2 works. Some containers/sandboxes restrict `/proc/self/pagemap`; the demo then prints a warning and
  falls back to page-fault counting only.

## Build

```bash
git clone <your-repo-url> cow-demo && cd cow-demo
make            # builds ./cow_demo and ./simcow
```

## Run

```bash
./cow_demo                       # default demo: 32 pages, child writes 8, parent writes 4
./cow_demo -p 64 -w 16 -m 8      # custom: 64 pages, child writes 16, parent then writes 8
sudo ./cow_demo --pfn            # also show physical frame numbers (PFN)
./cow_demo --bench --sizes 16,64,128,256      # timing benchmark (add --csv for CSV)
./simcow                         # step-by-step simulation of the COW algorithm
make test                        # run all automated tests
```

Options: `-p/--pages N`, `-w/--write K` (pages the child writes), `-m/--parent-write M`, `--pfn`,
`--bench`, `--sizes LIST`, `--csv`, `-h`.

### Reading the output

```
      PPPPPPPP########################
```
`#` = page shared between parent and child (COW-protected), `P` = private to this process.
Run the default demo and watch the map change at each step: all `P` -> all `#` (fork) -> still all `#`
(child reads) -> first 8 become `P` (child writes) -> 12 `P` (parent writes 4 more).

### Sample results (recorded in `results/`)

* 16/16 checks pass in the default scenario; 10/10 automated tests pass.
* Child read pass: **0** page faults. Child write of 8 pages: **8** page faults.
* PFN of page 0 is identical in both processes until the child writes; afterwards the child's page 0 has a
  different PFN while the parent keeps the original.
* `fork()` of a 256 MB process: ~1.8 ms; eagerly copying the same 256 MB: ~140 ms.
  Cost of one COW fault: ~2.5 us/page; second write to the same page: ~0.01 us.

## Safety / controlled environment

The program allocates at most a few MB for the demo (the benchmark up to the sizes you request, default
<= 128 MB), creates exactly one child process which exits normally, writes nothing to disk and needs no
privileges. It only reads `/proc/self/pagemap` of its own processes. Do not run the benchmark with sizes
larger than your free RAM.

## Repository layout

```
src/cow_demo.c   src/simcow.c   tests/run_tests.sh   Makefile
docs/REPORT.md   docs/DEMO_SCRIPT.md   docs/TEAM.md
results/         recorded outputs used in the report and slides
presentation/    slide deck (.pptx)
```

## Originality and references

All code in this repository was written by the project team for this assignment. Concepts follow
standard OS literature (Silberschatz *Operating System Concepts*, ch. "Memory Management"; Linux kernel
documentation `Documentation/admin-guide/mm/pagemap.rst`; `man 2 fork`, `man 5 proc`). No third-party code is used.

License: MIT.
