# Project Report - Copy-on-Write Memory Demonstrator

**Course:** Operating Systems  |  **Team:** _<fill in names / roll numbers>_  |  **Date:** _<fill in>_

## 1. Abstract
`fork()` appears to duplicate a whole process, yet it returns in about a millisecond even for hundreds of
megabytes. The reason is Copy-on-Write (COW): parent and child initially share the same physical pages and
the kernel copies a page only when one process writes to it. This project builds a working demonstrator that
makes this invisible mechanism visible and measurable on Linux, together with a user-space simulator of the
algorithm, an automated test-suite and a performance benchmark.

## 2. Problem statement
Develop a demonstration system showing how memory is shared after `fork()` and copied only when a process
modifies it. The system must be verifiable, repeatable, safe to run, and explainable.

## 3. Background
* **Virtual memory / paging.** Each process has a page table mapping virtual pages to physical frames.
* **fork().** Creates a child with a copy of the parent's address space. A naive implementation copies every
  frame (cost proportional to memory size).
* **Copy-on-Write.** fork copies only the page tables, increments a reference count on every frame and marks
  the entries read-only. A write then raises a protection page fault; the handler checks the frame's
  reference count: if > 1 it allocates a new frame, copies 4 KiB, updates the writer's entry to the new
  writable frame and decrements the old count; if == 1 it merely re-enables write permission.
* **Benefits.** Fast fork, lower memory use, and `fork()+exec()` (shell, servers) copies almost nothing.
  Also used by Redis background saves, container layers and `MAP_PRIVATE` file mappings.

## 4. System design
```
 parent            fork()            parent  ----\                 +--------+
 [PT]--->frames    ======>           [PT] (RO)    >---> frames --> | frame  |  refcount = 2
                                     child  ----/                  +--------+
                                     [PT] (RO)
 child writes page k  -> fault -> copy frame -> child [PT][k] -> new frame (RW), old refcount = 1
```
**Modules**
1. *Scenario engine* (`run_demo`): parent allocates N pages with an `mmap` anonymous private region and fills
   each with a known pattern; forks; then drives the child through *inspect -> read -> write K pages* using
   a command pipe so output is strictly ordered; finally the parent writes M other pages.
2. *Observer*: per-page state from `/proc/self/pagemap` (each process opens its own, because the file
   descriptor is bound to the opener's address space), fault counts via `getrusage`, optional PFN.
3. *Verifier*: checks page contents in both processes after every step (isolation) and asserts expected
   page-state counts and fault counts; prints PASS/FAIL; non-zero exit on failure.
4. *Benchmark*: measures `fork()` latency, eager `memcpy` of the same size, first-write (COW) and
   second-write pass times in the child.
5. *Simulator* (`simcow`): explicit page tables + frame reference counts, reproducing fork/read/write
   including the "last owner, no copy" optimisation.

**Design decisions.** Transparent huge pages are disabled for the region (`MADV_NOHUGEPAGE`) so that a
write copies 4 KiB, not 2 MiB. The child's stack page is warmed up before counting faults so that the
count reflects only the data pages. A tolerance of 3 faults is allowed for incidental kernel activity.

## 5. Technologies
C11, POSIX (`fork`, `pipe`, `mmap`, `waitpid`, `madvise`), Linux `/proc/self/pagemap`, `getrusage`,
GNU Make, Bash (tests), Git/GitHub.

## 6. Implementation summary
| Step | Action | Expected | Mechanism shown |
|------|--------|----------|-----------------|
| 1 | parent fills N pages | all private | baseline |
| 2 | `fork()` | all N pages shared, no copy | page tables copied, refcount = 2 |
| 3 | child reads all | 0 faults, still shared | read needs no copy |
| 4 | child writes K pages | K faults, K pages private, parent unaffected | COW fault + isolation |
| 5 | parent writes M pages | M faults, private = K + M; child's view matches | symmetric; "last owner" |
| 6 | cleanup | child exits 0 | no leaks |

## 7. Testing and validation
Automated by `make test` (all passed):

| ID | Scenario | Purpose |
|----|----------|---------|
| T1 | 32 pages, child 8, parent 4 | default case |
| T2 | child writes 0 | pure sharing, no copies |
| T3 | child writes all 64 | worst case: everything copied |
| T4 | 1-page region | boundary |
| T5 | 1024 pages (4 MiB) | scale |
| T6 | parent-heavy writes | symmetry |
| T7 | simulator assertions | algorithm correctness |
| T8 | benchmark CSV output | tooling |
| T9 | invalid argument rejected | input validation |
| T10 | 5 repeated runs | repeatability / no flakiness |

Each demo run performs 16 internal checks (page states, fault counts, content isolation).

## 8. Results
Environment: Linux 6.18, 1 vCPU, 4 GiB RAM, 4 KiB pages (numbers vary by machine).

**Demo (default run):** after `fork` 32/32 pages shared; child read pass: 0 faults; child wrote 8 pages:
8 faults, map `PPPPPPPP####...`; parent saw 8 private + 24 shared and unchanged data; after the parent wrote
4 pages: 12 private / 20 shared in *both* processes. 16/16 checks passed.

**Physical frames (root, `--pfn`):** page 0 had PFN 0x1189c6 in both processes until the child wrote; the
child's page 0 then moved to PFN 0x1189e5 while the parent kept 0x1189c6. Untouched page 15 kept the same PFN
(0x1189e8) in both.

**Benchmark:**
| Size (MB) | fork() ms | eager copy ms | child 1st write pass ms | us/page (COW) | 2nd pass us/page |
|-----------|-----------|---------------|-------------------------|---------------|------------------|
| 16  | 0.13 | 6.5   | 10.1  | 2.48 | 0.009 |
| 64  | 0.51 | 30.5  | 39.7  | 2.43 | 0.013 |
| 128 | 0.88 | 68.6  | 85.9  | 2.62 | 0.011 |
| 256 | 1.80 | 139.6 | 179.4 | 2.74 | 0.011 |

**Interpretation.** `fork()` is ~75-80x cheaper than an eager copy at 256 MB because it copies page tables
only. The price is deferred: the first write to each page costs ~2.5 us (fault + 4 KiB copy), ~250x more than
a normal write, but it is paid only for pages actually modified. If a child modifies *every* page, total cost
(fork + faults) is slightly above an eager copy - COW wins when only a fraction of pages are touched, which is
the typical `fork()+exec()` pattern.

## 9. Impact and applications
Faster process creation; lower memory footprint; enabling technology for shells, web servers
(pre-fork), Redis/PostgreSQL snapshots, container image layers, `MAP_PRIVATE` file mappings, VM
snapshots/KSM, and as a teaching tool for virtual memory.

## 10. Limitations and future work
Linux-specific observer; accuracy of fault counts depends on kernel noise (tolerance used); huge-page COW
(2 MiB) not explored; extend to `MAP_PRIVATE` file mappings, `vfork` vs `fork`, multi-threaded parents, and
a GUI/visualisation of the page map.

## 11. Responsible implementation
Controlled, bounded memory use; exactly one child, always reaped; no disk writes; no privileges required;
no interference with other processes (reads only its own `/proc/self`). Code is original; references listed
in the README.

## 12. References
1. Silberschatz, Galvin, Gagne - *Operating System Concepts*, virtual memory chapter.
2. Linux kernel documentation - `admin-guide/mm/pagemap.rst`.
3. `man 2 fork`, `man 2 mmap`, `man 2 getrusage`, `man 5 proc`.
4. Bovet & Cesati - *Understanding the Linux Kernel*, "Copy On Write".
