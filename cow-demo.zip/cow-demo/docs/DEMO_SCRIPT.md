# Live Demonstration Script (about 7 minutes)

**Before:** `make clean && make` works; terminal font large; run `./cow_demo` once to confirm.

1. **(30 s) Problem.** "fork() looks like a full copy, but returns in ~1 ms. We show why."
2. **(60 s) Simulator.** `./simcow` - point at page tables `COW` flags, refcount 2, one frame copied.
3. **(2 min) Real kernel.** `./cow_demo`. Walk through the map after each step:
   all `P` -> all `#` after fork -> still `#` after reads (0 faults) -> `PPPPPPPP###...` after child writes
   (8 faults) -> parent view shows its originals unchanged -> parent writes -> 12 `P`.
4. **(1 min) Physical proof.** `sudo ./cow_demo --pfn -p 16 -w 4` - same PFN before write, child PFN differs after.
5. **(1 min) Variations.** `./cow_demo -p 64 -w 0` (nothing copied) and `./cow_demo -p 64 -w 64` (everything copied).
6. **(1 min) Benchmark.** `./cow_demo --bench --sizes 16,64,128` - fork ms vs eager copy ms.
7. **(30 s) Tests.** `make test` -> 10/10 pass.

## Likely viva questions
* **Why is fork fast?** Copies page tables, not data; frames shared with refcount.
* **What happens on the write?** Protection fault -> handler: refcount>1 -> allocate, copy 4 KiB, remap RW, refcount--.
* **What if the refcount is 1?** Just mark writable; no copy (last-owner optimisation - see `simcow`).
* **Does reading copy?** No; 0 faults observed.
* **Why does the child reopen /proc/self/pagemap?** The fd is bound to the address space of the process that opened it.
* **Why MADV_NOHUGEPAGE?** Otherwise a write could copy 2 MiB, hiding the page-level behaviour.
* **Is COW free?** No: first write ~2.5 us/page here; if all pages are written, total >= eager copy.
* **Where else is COW used?** `fork+exec`, Redis snapshots, containers, VM snapshots, MAP_PRIVATE files.
* **What does `#`/`P` mean?** pagemap bit 56 (exclusively mapped): `P` = mapped by one process only.
* **Why a tolerance of 3 faults?** Kernel/libc may touch a few extra pages (stack, stdio) - not our data pages.
* **Safety?** One child, bounded memory, no disk writes, no root required.
