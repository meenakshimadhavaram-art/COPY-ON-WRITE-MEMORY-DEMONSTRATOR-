# Team Roles (edit names before submission)

Every member must be able to explain their module and the concept behind it.

| Member | Role | Owns | Be ready to explain |
|--------|------|------|---------------------|
| _Member 1_ | Core engineer | `run_demo`, fork/pipe orchestration | fork, pipes, process sync, why child reopens pagemap |
| _Member 2_ | Observer / kernel interface | `/proc/self/pagemap`, `getrusage`, PFN | page-table entry bits, minor vs major faults |
| _Member 3_ | Testing & benchmark | `tests/run_tests.sh`, `--bench`, `results/` | test design, why COW wins/loses, interpreting numbers |
| _Member 4_ | Simulator & documentation | `simcow.c`, README, report | refcount algorithm, last-owner optimisation, report |
| _Member 5 (optional)_ | Presentation & demo lead | slides, `DEMO_SCRIPT.md`, GitHub | storyline, live demo flow |

Suggested commit convention: each member commits their own files so GitHub history shows contributions.
