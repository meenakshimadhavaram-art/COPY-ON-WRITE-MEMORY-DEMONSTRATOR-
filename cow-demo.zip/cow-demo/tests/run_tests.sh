#!/usr/bin/env bash
# Automated test-suite for the COW demonstrator.  Run from repo root:  make test
set -u
cd "$(dirname "$0")/.."
pass=0; fail=0
run() {  # run <name> <command...>
  local name="$1"; shift
  if out=$("$@" 2>&1); then echo "[PASS] $name"; pass=$((pass+1))
  else echo "[FAIL] $name"; echo "$out" | tail -15; fail=$((fail+1)); fi
}
run "T1 default scenario (32 pages, child 8, parent 4)"  ./cow_demo
run "T2 child writes nothing (read-only sharing)"         ./cow_demo -p 64 -w 0 -m 0
run "T3 child writes every page (full copy)"              ./cow_demo -p 64 -w 64 -m 0
run "T4 single page region"                               ./cow_demo -p 1 -w 1 -m 0
run "T5 large region (1024 pages = 4 MiB)"                ./cow_demo -p 1024 -w 256 -m 128
run "T6 parent-heavy writes"                              ./cow_demo -p 100 -w 5 -m 90
run "T7 user-space simulator assertions"                  ./simcow
run "T8 benchmark runs and produces CSV rows"             bash -c './cow_demo --bench --csv --sizes 4,8 | grep -c "^[0-9]" | grep -qx 2'
run "T9 invalid page count rejected"                      bash -c '! ./cow_demo -p 0'
run "T10 repeatability (5 consecutive runs)"              bash -c 'for i in 1 2 3 4 5; do ./cow_demo -p 48 -w 12 -m 6 >/dev/null || exit 1; done'
echo "-----------------------------------"
echo "tests passed: $pass   failed: $fail"
[ "$fail" -eq 0 ]
